//
//  ContactsTableViewController.swift
//  Dopuna
//
//  Created by Anel Hadzic on 23/09/16.
//  Copyright © 2016 Anel Hadzic. All rights reserved.
//

import UIKit
protocol ContactTableViewDelegate: class {
    func didPressCellWithTitle(contact: Contact)
    
}

class ContactTableViewController: UITableViewController, UINavigationControllerDelegate {
    // MARK: Properties
    
    var delegate: ContactTableViewDelegate?
    var contacts = [Contact]()
    var selectedContact: Contact? {
        didSet {
            if let contact = selectedContact {
                selectedContactIndex = contacts.indexOf(contact)!
            }
        }
    }
    var selectedContactIndex: Int?
    
    @IBOutlet weak var selectedContactCell: ContactTableViewCell!
    @IBOutlet weak var editContactButton: UIBarButtonItem!
    /* @IBOutlet weak var editContactButton: UIBarButtonItem! 
     */
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadSampleContacts()
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return contacts.count
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cellIdentifier = "Cell"
        
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath) as! ContactTableViewCell
        let contact = contacts[indexPath.row]
        
        cell.nameLabel.text = contact.name
        cell.phoneNumberLabel.text = contact.phoneNumber
        
        if cell.nameLabel.text == "" {
            cell.nameLabel.text = contact.phoneNumber
            cell.phoneNumberLabel.text = ""
        }
        
        
        
        if indexPath.row == selectedContactIndex {
            cell.accessoryType = .Checkmark
        } else {
            cell.accessoryType = .None
        }
        
        return cell
        
    }
        
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        if let index = selectedContactIndex {
            let cell = tableView.cellForRowAtIndexPath(NSIndexPath(forRow: index, inSection: 0))
            cell?.accessoryType = .None
        }
        
        selectedContact = contacts[indexPath.row]
        
        
        let cell = tableView.cellForRowAtIndexPath(indexPath)
        cell?.accessoryType = .Checkmark
        
        delegate?.didPressCellWithTitle((selectedContact)!)
        
        self.navigationController?.popViewControllerAnimated(true)
        
        
    }
    
    @IBAction func unwindToContactsList(sender: UIStoryboardSegue) {
        if let sourceViewController = sender.sourceViewController as? NewContactViewController, contact = sourceViewController.contact{
        
        let newIndexPath = NSIndexPath(forRow: contacts.count, inSection: 0)
            
        contacts.append(contact)
        tableView.insertRowsAtIndexPaths([newIndexPath], withRowAnimation: .Bottom)
           saveContacts()
        }
    }
    
        func loadSampleContacts() {
            
            let contact1 =  Contact(name: "Nikola Tesla", phoneNumber: "+38761555000")!
            let contact2 = Contact(name: "Ivo Andric", phoneNumber: "+38765999111")!
            let contact3 = Contact(name: "Roberto Carlos", phoneNumber: "+38761001002")!
            
            contacts += [contact1, contact2, contact3]
        }
        
        func saveContacts(){
            let isSuccessfulSave = NSKeyedArchiver.archiveRootObject(contacts, toFile: Contact.ArchiveURL.path!)
            if !isSuccessfulSave{
                print("Failed to save contact")
            }
        }

/*
 // Override to support conditional editing of the table view.
 override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
 // Return false if you do not want the specified item to be editable.
 return true
 }
 */


 // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            contacts.removeAtIndex(indexPath.row)
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
 } else if editingStyle == .Insert {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }
 }


/*
 // Override to support rearranging the table view.
 override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {
 
 }
 */

/*
 // Override to support conditional rearranging of the table view.
 override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
 // Return false if you do not want the item to be re-orderable.
 return true
 }
 */



   
}

