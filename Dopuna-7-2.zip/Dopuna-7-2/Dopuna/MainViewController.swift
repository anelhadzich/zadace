//
//  MainViewController.swift
//  Dopuna
//
//  Created by Anel Hadzic on 26/09/16.
//  Copyright © 2016 Anel Hadzic. All rights reserved.
//

import UIKit
import MessageUI

class MainViewController: UIViewController, UINavigationControllerDelegate,MFMessageComposeViewControllerDelegate, ContactTableViewDelegate  {
    
    @IBOutlet weak var addContact: UIButton!
    @IBOutlet weak var network: UISegmentedControl!
    @IBOutlet weak var amount: UISegmentedControl!
    @IBOutlet weak var chargeContact: UIButton!

   // var amountMTEL = 0
   // var amountBHT = 0
    
    
    
    var contact: Contact?
    var selectedPhoneNumber : String = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "Dopuna"
    }
       // print(network.selectedSegmentIndex)
       // print(amount.selectedSegmentIndex)

        //MARK: Segmented control
   /* @IBAction func amountOfCreditMTEL(sender: UISegmentedControl) {
        amountMTEL = sender.selectedSegmentIndex
    }
    @IBAction func amountOfCreditBHT(sender: UISegmentedControl) {
        amountBHT = sender.selectedSegmentIndex
    }
    */
    
       @IBAction func selectNetwork(sender: UISegmentedControl){
        if network.selectedSegmentIndex == 0 {
                amount.setTitle("2 KM", forSegmentAtIndex: 0)
                amount.setTitle("3 KM", forSegmentAtIndex: 1)
                amount.setTitle("4 KM", forSegmentAtIndex: 2)
                amount.setTitle("5 KM", forSegmentAtIndex: 3)
                amount.setTitle("10 KM", forSegmentAtIndex: 4)
                
            }
            if network.selectedSegmentIndex == 1 {
                amount.setTitle("1 KM", forSegmentAtIndex: 0)
                amount.setTitle("2 KM", forSegmentAtIndex: 1)
                amount.setTitle("5 KM", forSegmentAtIndex: 2)
                amount.setTitle("10 KM", forSegmentAtIndex: 3)
                amount.setTitle("20 KM", forSegmentAtIndex: 4)
                
            }
    }
    
   @IBAction func chargeCredit(sender: UIButton){
        
        
        if !MFMessageComposeViewController.canSendText() {
            print("NE MOZE, ALERT")
            
            let alertController = UIAlertController(title: "Obavijest", message: "Ovaj uređaj ne može poslati poruku.", preferredStyle: .Alert)
            
            let OKAction = UIAlertAction(title: "Ok", style: .Default, handler: nil)
            alertController.addAction(OKAction)
            self.presentViewController(alertController, animated: true, completion:nil)
            
        } else {
    
            let composeVC = MFMessageComposeViewController()
            composeVC.delegate = self
            
            var amountOfCredit = amount.titleForSegmentAtIndex(amount.selectedSegmentIndex)?.componentsSeparatedByString(" ")
            let chosenAmount = amountOfCredit! [0] + selectedPhoneNumber
            let mtel = "D"
            let bht = ""
        
        if network.selectedSegmentIndex == 0 {
            composeVC.recipients = ["0651110"]
            composeVC.body = (mtel + chosenAmount)
        } else {
            composeVC.recipients = ["0611171"]
            composeVC.body = (bht + chosenAmount)
        }
            self.presentViewController(composeVC, animated: true, completion: nil)
        
        }
    
    }
    
    func messageComposeViewController(controller: MFMessageComposeViewController, didFinishWithResult result: MessageComposeResult) {
        
        controller.dismissViewControllerAnimated(true, completion: nil)
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: DODAJ KONTAKT
    
    func didPressCellWithTitle(contact: Contact) {
        if contact.name == "" {
            addContact.titleLabel?.text = contact.phoneNumber
        } else {
            addContact.titleLabel?.text = contact.name
        }
        selectedPhoneNumber = contact.phoneNumber
        
    }
    
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if let contactVC = segue.destinationViewController as? ContactTableViewController {
            contactVC.delegate = self
        }
}
}

