//
//  ViewController.swift
//  Dopuna
//
//  Created by Anel Hadzic on 23/09/16.
//  Copyright © 2016 Anel Hadzic. All rights reserved.
//

import UIKit

/*protocol AddNewContactDelegate {
    func addContactPressed(controller: NewContactViewController, contact: Contact)
}
*/
class NewContactViewController: UIViewController, UITextFieldDelegate {
    
    var contact: Contact?
  //  var delegate: AddNewContactDelegate?
    
    
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var phoneNumberTextField: UITextField!
    @IBOutlet weak var saveButton: UIBarButtonItem!
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        nameTextField.delegate = self
        phoneNumberTextField.delegate = self
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func addNewContact (){
        if nameTextField.text!.isEmpty  {
            
        }
        else {
            contact = Contact(name: nameTextField.text, phoneNumber: phoneNumberTextField.text!)
        }
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if sender === saveButton   {
            let name = nameTextField.text ?? ""
            let number = "+387" + phoneNumberTextField.text!
            
            contact = Contact(name: name, phoneNumber: number)
        }
    }
    
    
    
}




