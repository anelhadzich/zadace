//
//  Meal.swift
//  FoodTracker
//
//  Created by Anel Hadzic on 31/08/16.
//  Copyright © 2016 Anel Hadzic. All rights reserved.
//

import Cocoa

class Meal: UITableViewCell {

}
